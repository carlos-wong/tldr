# yes

> Exibe algo na tela repetidamente.

- Exibir na tela a palavra "mensagem" repetidamente:

`yes {{mensagem}}`

- Exibir na tela a letra "y" repetidamente::

`yes`
