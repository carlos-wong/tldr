# yarn-why

> Identifica por que um pacote Yarn foi instalado.
> Página oficial: <https://www.npmjs.com/package/yarn-why>.

- Exibir na tela o motivo de um pacote Yarn estar instalado:

`yarn-why {{nome_do_pacote}}`
