# mkdir

> Criar um diretório.

- Criar um diretório:

`mkdir {{nome_do_diretorio}}`

- Criar recursivamente uma árvore de diretórios aninhados:

`mkdir {{caminho/para/subdiretorio}}`
