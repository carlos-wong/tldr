# type

> Mostrar o conteúdo de um arquivo.

- Mostrar o conteúdo de um arquivo específico:

`type {{caminho/para/arquivo}}`
