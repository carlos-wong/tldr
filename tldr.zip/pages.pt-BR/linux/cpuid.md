# cpuid

> Exibe informações detalhadas sobre todas as CPUs.

- Exibir informações de todas as CPUs:

`cpuid`

- Exibir informações apenas da CPU atual:

`cpuid -1`

- Exibir informações em hexadecimal sem decodificação:

`cpuid -r`
