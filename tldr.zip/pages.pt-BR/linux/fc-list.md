# fc-list

> Exibe todas as fontes disponíveis no sistema.

- Exibir as fontes instaladas correspondentes ao critério de busca:

`fc-list | grep '{{criterio_de_busca}}'`
