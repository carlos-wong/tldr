# fatlabel

> Define ou exibe o rótulo de uma partição FAT32.

- Exibir o rótulo de uma partição FAT32:

`fatlabel {{/dev/sda1}}`

- Definir o rótulo de uma partição FAT32:

`fatlabel {{/dev/sdc3}} "{{rotulo}}"`
