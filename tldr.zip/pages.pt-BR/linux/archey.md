# archey

> Ferramenta que exibe informações do sistema de forma estilizada.

- Exibir as informações do sistema:

`archey`
