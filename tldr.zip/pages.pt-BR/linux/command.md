# command

> Obriga o shell a executar o programa, ignorando qualquer função ou alias com o mesmo nome.

- Executar o programa ls, mesmo que exista algum alias ls:

`command {{ls}}`
