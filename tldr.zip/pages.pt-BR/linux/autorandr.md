# autorandr

> Altera o layout da tela automaticamente.

- Salvar o layout da tela em uso:

`autorandr -s {{nome_do_perfil}}`

- Exibir os perfis salvos:

`autorandr`

- Alterar o perfil:

`autorandr -l {{nome_do_perfil}}`

- Definir o perfil padrão:

`autorandr -d {{nome_do_perfil}}`
