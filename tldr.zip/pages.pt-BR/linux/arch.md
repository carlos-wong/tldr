# arch

> Exibir o nome da arquitetura do sistema.
> Veja também `uname`.

- Exibir a arquitetura do sistema:

`arch`
