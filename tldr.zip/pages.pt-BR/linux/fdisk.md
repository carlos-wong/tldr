# fdisk

> Gerenciador de tabelas de partições e partições no disco rígido.

- Exibir as partições:

`fdisk -l`

- Iniciar o manipulador de partições:

`fdisk {{/dev/sda}}`
