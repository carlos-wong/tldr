# clear

> Pulisce lo schermo del terminale.

- Pulisci lo schermo (equivalente a Control+L se si utilizza la shell bash):

`clear`
