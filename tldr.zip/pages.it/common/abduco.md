# abduco

> Gestore di sessioni di terminale.

- List sessioni:

`abduco`

- Entra in una sessione, creandola se non esiste già:

`abduco -A {{nome_sessione}} {{bash}}`

- Entra in una sessione con `dvtm`, creandola se non esiste già:

`abduco -A {{nome_sessione}}`

- Esci da una sessione:

`CTRL + \`

- Entra in una sessione in modalità sola lettura:

`abduco -Ar {{nome_sessione}}`
