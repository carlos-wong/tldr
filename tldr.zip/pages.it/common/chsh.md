# chsh

> Cambia shell di login dell'utente.

- Cambia shell:

`chsh -s {{percorso/a/eseguibile_della_shell}} {{nome_utente}}`
