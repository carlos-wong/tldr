# apm

> Atom编辑器的包管理工具.
> 参见 `atom`.

- 下载包: http://atom.io/packages 和主题 http://atom.io/themes:

`apm install {{包名}}`

- 移除包/主题:

`apm remove {{包名}}`

- 升级包/主题:

`apm upgrade {{包名}}`
