# choco feature

> Chocolatey的交互功能.

- 显示可用的功能列表:

`choco feature list`

- 启用一个功能:

`choco feature enable --name {{功能名称}}`

- 禁用一个功能:

`choco feature disable --name {{功能名称}}`
