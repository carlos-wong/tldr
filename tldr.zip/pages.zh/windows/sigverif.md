# sigverif

> 用于检查系统文件的GUI签名验证工具.

- 打开文件签名验证界面:

`sigverif`
