# pwlauncher

> 用于管理Windows To Go启动选项的命令行工具.

- 显示当前Windows To Go的状态:

`pwlauncher`

- 启用或禁用Windows To Go的启动选项:

`pwlauncher /{{enable|disable}}`
