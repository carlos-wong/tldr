# ver

> 显示当前Windows或MS-DOS的版本号.

- Display the current version number:

`ver`
