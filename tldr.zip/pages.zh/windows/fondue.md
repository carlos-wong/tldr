# fondue

> 可选Windows功能的命令行安装程序.

- 启用一个指定的Windows功能:

`fondue /enable-feature:{{功能}}`

- 向用户隐藏所有输出信息:

`fondue /enable-feature:{{功能}} /hide-ux:all`

- 为错误报告指定调用者进程名称:

`fondue /enable-feature:{{功能}} /caller-name:{{名称}}`
