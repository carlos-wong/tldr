# runit

> 三级初始化系统.

- 启动 runit 的三阶段初始化方案:

`runit`

- 停止运行 runit:

`kill --CONT {{runit进程id}}`
