# brightness

> 获取或设置所有显示设备的亮度等级.

- 显示当前亮度:

`brightness -l`

- 设置亮度到 100%::

`brightness {{1}}`

- 设置亮度到 50%::

`brightness {{0.5}}`
