# sw_vers

> 打印 MacOS 软件版本信息.

- 打印 MacOS 版本:

`sw_vers -productVersion`

- 打印 MacOS 构建版本:

`sw_vers -buildVersion`
