# archey

> 漂亮地显示简单系统信息工具.

- 显示系统信息(彩色的):

`archey`

- 显示系统信息(单色的):

`archey --nocolor`

- 显示系统信息, 使用 MacPorts(命令行软件安装管理工具port)来替代Homebrew(另一种更常用的mac命令行软件安装管理工具):

`archey --macports`

- 显示系统信息,但不进行IP地址获取和验证:

`archey --offline`
