# apachectl

> 用于macOS的Apache HTTP Server控制接口(工具).

- 启动 org.apache.httpd 服务:

`apachectl start`

- 停止已启动的服务:

`apachectl stop`

- 重新启动服务:

`apachectl restart`
